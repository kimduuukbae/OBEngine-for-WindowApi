#include <Windows.h>
#include "Define.h"
#include "SceneLogo.h"
#include "SceneGame.h"
#pragma comment(lib, "OBEngine.lib")

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int){
	D_WORLD->worldInit("Sample", 1024, 768, hInstance);
	D_WORLD->setFrame(60.0f);

	D_SCENE->commit("Logo", new SceneLogo);
	D_SCENE->changeScene("Logo");

	D_SOUND->init(1);

	D_SOUND->commit("Resource/LogoSound.mp3", 2);
	D_SOUND->commit("Resource/GameSound.mp3", 2);
	D_SOUND->commit("Resource/HitSound.mp3", 0);
	D_SOUND->commit("Resource/DamageSound.mp3", 0);



	D_WORLD->runLoop();
}
