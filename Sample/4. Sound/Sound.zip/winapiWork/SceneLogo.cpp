#include "SceneLogo.h"
#include "Define.h"

/*
	LogoScene.cpp
*/
void SceneLogo::init(){
	D_SOUND->playSound(E_LOGO);
}

void SceneLogo::update(float dt){

}

void SceneLogo::draw(HDC hDC){
	image1.draw(hDC);
}

void SceneLogo::destroy(){
}

