#pragma once
#include "Scene.h" 
#include "Sprite.h"

class SceneLogo : public Scene {
public:
	virtual void init() override;
	virtual void update(float dt) override;
	virtual void draw(HDC hDC) override;
	virtual void destroy() override;

private:
	Sprite image1;
};
