#include <Windows.h>
#include "Define.h"
#include "SceneLogo.h"
#include "SceneGame.h"
#pragma comment(lib, "OBEngine.lib")

#ifdef UNICODE
#pragma comment(linker, "/entry:wWinMainCRTStartup /subsystem:console") 
#else
#pragma comment(linker, "/entry:WinMainCRTStartup /subsystem:console") 
#endif


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int){
	D_WORLD->worldInit("Sample", 1024, 768, hInstance);
	D_WORLD->setFrame(60.0f);

	D_SCENE->commit("Game", new SceneGame);
	D_SCENE->commit("Logo", new SceneLogo);

	D_SCENE->changeScene("Game");

	D_WORLD->runLoop();
}
