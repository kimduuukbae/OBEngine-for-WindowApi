#include "SceneGame.h"
#include "Define.h"
#include "Hero.h"

/*
	GameScene.cpp
*/
void SceneGame::init(){
	m_Hero = new Hero();
}

void SceneGame::update(float dt){
	m_Hero->update(dt);
}

void SceneGame::draw(HDC hDC){
	m_Hero->draw(hDC);
}

void SceneGame::destroy(){
	delete m_Hero;
}
