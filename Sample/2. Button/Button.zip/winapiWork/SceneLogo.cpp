#include "SceneLogo.h"
#include "Define.h"
void SceneLogo::init(){
	button1.setTexture("Resource/startButton.bmp");
	button1.setPos(250, 250);
}

void SceneLogo::update(float dt){

}

void SceneLogo::draw(HDC hDC){
	button1.draw(hDC);
}

void SceneLogo::destroy(){
}

void SceneLogo::mouseDownEvent(const Vector2D& mousePos) {
	if (button1.collision(mousePos.getX(), mousePos.getY()))
		D_SCENE->changeSceneFade("Game");
}
